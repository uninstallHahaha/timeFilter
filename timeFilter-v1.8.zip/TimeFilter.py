import pandas as pd
from pandas import DataFrame, Series
import numpy as np
from datetime import *
import json
import time as tim
from tqdm import tqdm
import os
import sys
import logging


class Datagram:
    # 1. 静止, 2.行走, 3.吃草
    def __init__(self):
        self.static_datagram = DataFrame()
        self.walk_datagram = DataFrame()
        self.eat_datagram = DataFrame()

    def __setitem__(self, key, value):
        self.key = value


# json file to obj
def json_reader(path):
    print('>>>正在读取设置...')
    f = open(path, encoding='utf-8')
    obj = json.load(f)
    print('>>>设置读取完成')
    return obj


# str to datetime.time
def time_parser(value: str) -> time:
    if value == '':
        return ''
    ts = value.split(':')
    if len(ts[2].split('.')) > 1:
        mill_second = int(ts[2].split('.')[1])
    else:
        mill_second = 0

    refer_time = time(int(ts[0]), int(ts[1]), int(ts[2].split('.')[0]), mill_second)
    return refer_time


# pre local the correct sheet
def shrink_dataset(origin: list, val1: time, val2: time, column_name='time') -> DataFrame:
    # s: DataFrame
    res = None
    for s in origin:
        col = s[column_name]
        first = time_parser(col.iloc[0])
        last = time_parser(col.iloc[-1])
        min_val = first if first < last else last
        max_val = last if first < last else first
        # range beyond append
        if res is not None:
            if max_val >= val2:
                return pd.concat([res, s], axis=0)
            else:
                res = pd.concat([res, s], axis=0)
                continue
        # range content
        if min_val <= val1 and max_val >= val2:
            return s
        # range beyond
        if min_val <= val1 <= max_val < val2:
            if res is None:
                res = s
    return None


# 二分查找
# 返回筛选结果和上下界索引
def divide_find(fill_data: DataFrame, val1: time, val2: time, column_name='time') -> (DataFrame, int, int):
    time_column_list = list(map(time_parser, fill_data[column_name]))
    start = 0
    end = len(time_column_list) - 1
    loc = -1
    if time_column_list[start] > val2 or time_column_list[end] < val1:
        return DataFrame(columns=fill_data.columns), -1, -1
    while end > start:
        mid = (end - start) // 2 + start
        if start == mid and not (val1 <= time_column_list[mid] <= val2):
            break
        if val1 <= time_column_list[mid] <= val2:
            loc = mid
            break
        if time_column_list[mid] > val2:
            end = mid
            continue
        if time_column_list[mid] < val1:
            start = mid
            continue
    # not exist , return directly
    if loc == -1:
        return DataFrame(columns=fill_data.columns), -1, -1
    # step by step to found the edge of limitation
    xfound = False
    yfound = False
    x = loc
    y = loc
    while (not xfound) or (not yfound):
        if not xfound:
            if x - 1 >= 0 and val1 <= time_column_list[x - 1] <= val2:
                x -= 1
            else:
                xfound = True
        if not yfound:
            if y + 1 < len(time_column_list) and val1 <= time_column_list[y + 1] <= val2:
                y += 1
            else:
                yfound = True
    return fill_data.iloc[x:y + 1], x, y


# equal 相等
# lt 小于
# gt 大于
# lte 小于等于
# gte 大于等于
# range 范围
def mode_justifier(fill_data: DataFrame, mode: str, value1: time, value2: time, column_name='time') -> (
        DataFrame, DataFrame):
    res = None
    remain = None
    if mode == 'equal':
        res = fill_data[fill_data[column_name] == value1]
    if mode == 'lt':
        res = fill_data[fill_data[column_name] < value1]
    if mode == 'gt':
        res = fill_data[fill_data[column_name] > value1]
    if mode == 'lte':
        res = fill_data[fill_data[column_name] <= value1]
    if mode == 'gte':
        res = fill_data[fill_data[column_name] >= value1]
    if mode == 'range':
        res, x, y = divide_find(fill_data=fill_data, val1=value1, val2=value2, column_name='time')

        # no longer calculate remain
        # remain = fill_data.iloc[:x].append(fill_data.iloc[y + 1:])
        remain = None

        res = res.fillna('*')
    return res, remain


# 检查是否有上次结果
def check_last_res(paths):
    for p in paths:
        if os.path.exists(p):
            return True
    return False


# 开局清理上次筛选结果
def clearer(paths):
    print('>>>正在清理历史数据...')
    for p in paths:
        if os.path.exists(p):
            os.remove(p)
    print('>>>历史数据清理完毕')


# 根据不同的类型保存到不同的变量中
def append_datagram(res: DataFrame, time_filter: Datagram, act_type: int) -> str:
    if act_type == 1:
        time_filter.static_datagram = append_res(res, time_filter.static_datagram)
    if act_type == 2:
        time_filter.walk_datagram = append_res(res, time_filter.walk_datagram)
    if act_type == 3:
        time_filter.eat_datagram = append_res(res, time_filter.eat_datagram)
    # res.to_excel(path, index=False, header=False)
    return ''


# 追加到之前的筛选结果
def append_res(res, datagram):
    df = datagram
    if df is None or df.shape[0] == 0:
        return res
    res.index = map(lambda x: x, range(df.shape[0], df.shape[0] + res.shape[0]))
    res.columns = df.columns
    df.reset_index(drop=True)
    res.reset_index(drop=True)
    res = df.append(res, ignore_index=True)
    return res


# 从Datagram为保存一系列文件
def saver_all_files(dg: Datagram, paths: list):
    for attr, d in dg.__dict__.items():
        if attr == 'static_datagram':
            d.to_excel(paths[0], index=False, header=False)
        elif attr == 'walk_datagram':
            d.to_excel(paths[1], index=False, header=False)
        elif attr == 'eat_datagram':
            d.to_excel(paths[2], index=False, header=False)
        else:
            pass


# 其他筛选模式数据保存器
def saver(ret, file_name='result'):
    path = './' + file_name + '-' + str(round(tim.time()))[-1] + '.xlsx'
    ret.to_excel(path)
    print('保存成功: ' + path)


# 重建输出表格式
def re_format_table(datagram: Datagram, old_val='*', new_val=''):
    print('>>>正在重建输出表内容...')
    with tqdm(total=3, leave=True) as bar:
        bar.set_description("正在处理")
        for attr in list(datagram.__dict__.keys()):
            datagram.__dict__[attr] = datagram.__dict__[attr].replace(old_val, new_val)
            bar.update(1)
        print('>>>输出表内容重建完毕')
    return


# set logging
def set_logging(path='log.txt', formatter='%(asctime)s - %(name)s - %(levelname)s - %(message)s'):
    logger = logging.getLogger(__name__)
    logger.setLevel(level=logging.INFO)
    handler = logging.FileHandler(path)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter(formatter)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


if __name__ == '__main__':
    # 开启日志
    logger = set_logging(path='log_sheet_shrink.txt')
    # 读设置
    settings = json_reader('./settings.json')
    # 文件名
    base_name = settings["file_name"].split('.')[0]
    # 输出文件名
    paths = [base_name + '-静止.xlsx', base_name + '-行走.xlsx', base_name + '-吃草.xlsx']
    if check_last_res(paths):
        print('>>>检测到上次生成的结果, 新一轮的筛选操作将删除上一次结果, 请确保已备份相关数据(y/n)', end=' ')
        if input().lower() != 'y':
            print('>>>操作取消')
            sys.exit(0)
        else:
            # 清理上次结果
            clearer(paths)

    print('>>>正在读取数据...')
    time_start = tim.time()
    # 数据预处理
    datas = pd.read_excel(settings['file_name'], header=None, sheet_name=None)
    # 数据总量
    total = 0
    # 整表
    fillTable = None
    # sheet data list
    sheet_data_list = []
    print('>>>检测到该文件中包含' + str(len(datas.items())) + '个sheet')
    for sheet_name, data in datas.items():
        cols = ['-'] * data.shape[1]
        # continue if the sheet is not content time column
        if len(cols) < int(settings['time_column_num']):
            continue
        # set the filter column's name to 'time'
        cols[int(settings['time_column_num']) - 1] = 'time'
        data.columns = cols
        data.index = map(lambda x: x, range(total, total + data.shape[0]))
        # append to fillTable
        # fillTable = pd.concat([fillTable, data], axis=0)
        # append to list
        sheet_data_list.append(data)
        total += len(data)
    time_end = tim.time()
    print(f'>>>数据读取完成, 总共 {total} 条记录, 耗时 {round(time_end - time_start, 2)} 秒')

    # multi-range-filter
    if settings["mode"] == 'range':
        datagram = Datagram()
        print('>>>开始执行range筛选模式...')
        range_data = pd.read_excel(settings['range_file_name'], header=None)
        range_data_len = len(range_data)
        file_paths = []
        with tqdm(total=range_data_len, leave=True) as pbar:
            pbar.set_description("正在处理")
            for index, row in range_data.iterrows():
                if len(row) > 3:
                    continue
                t_start = tim.time()
                # time limitation
                val1 = time_parser(str(row[0]))
                val2 = time_parser(str(row[1]))
                # shrink the range of sheet
                tmpTable = shrink_dataset(sheet_data_list, val1, val2)
                if tmpTable is None:
                    pbar.update(1)
                    t_end = tim.time()
                    logger.info(f"第 {index} 号筛选条件(类别{int(row[2])})耗时 {round(t_end - t_start, 2)} 秒, 筛选结果为 0 条数据")
                    continue
                # get the record which is in the range
                ret, remain_data = mode_justifier(tmpTable, mode='range',
                                                  value1=val1,
                                                  value2=val2)
                t_end = tim.time()
                logger.info(
                    f"第 {index} 号筛选条件(类别{int(row[2])})耗时 {round(t_end - t_start, 2)} 秒, 筛选结果为 {ret.shape[0]} 条数据")
                # update fillTable to remain_data
                # fillTable = remain_data
                # update fill_data of classes
                append_datagram(ret, datagram, int(row[2]))
                pbar.update(1)
            print('>>>数据筛选完毕')
        # rebuild datagram & output to files
        re_format_table(datagram)
        # save all of files
        saver_all_files(datagram, paths)

    else:
        # other-mode
        ret = mode_justifier(fillTable, mode=settings['mode'], value1=time_parser(settings['value1']),
                             value2=time_parser(settings['value2']))
        saver(ret)
