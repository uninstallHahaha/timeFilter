import pandas as pd
from pandas import DataFrame, Series
import numpy as np
from datetime import *
import json
import time as tim
from tqdm import tqdm
import os
import sys


def json_reader(path):
    f = open(path, encoding='utf-8')
    obj = json.load(f)
    return obj


def time_perser(value):
    if value == '':
        return ''
    ts = value.split(':')
    if len(ts[2].split('.')) > 1:
        mill_second = int(ts[2].split('.')[1])
    else:
        mill_second = 0

    refer_time = time(int(ts[0]), int(ts[1]), int(ts[2].split('.')[0]), mill_second)
    return refer_time


# equal 相等
# lt 小于
# gt 大于
# lte 小于等于
# gte 大于等于
# range 范围
def mode_justifier(data, mode, value1, value2, column_name='time') -> (DataFrame, DataFrame):
    remain_data = None
    if mode == 'equal':
        ret = data[data[column_name] == value1]
    if mode == 'lt':
        ret = data[data[column_name] < value1]
    if mode == 'gt':
        ret = data[data[column_name] > value1]
    if mode == 'lte':
        ret = data[data[column_name] <= value1]
    if mode == 'gte':
        ret = data[data[column_name] >= value1]
    if mode == 'range':
        ret = data[value1 <= np.array(list(map(time_perser, data[column_name])))]
        ret = ret[value2 >= np.array(list(map(time_perser, ret[column_name])))]
        remain_data = data[np.logical_or(value1 > np.array(list(map(time_perser, data[column_name])))
                                         , np.array(list(map(time_perser, data[column_name]))) > value2)]
    ret = ret.fillna('*')
    return ret, remain_data


# 检查是否有上次结果
def check_last_res(paths):
    for p in paths:
        if os.path.exists(p):
            return True
    return False


# 开局清理上次筛选结果
def clearer(paths):
    print('>>>正在清理历史数据...')
    for p in paths:
        if os.path.exists(p):
            os.remove(p)
    print('>>>历史数据清理完毕')


# 根据不同的类型保存到不同的文件中
def switchSaver(ret: DataFrame, type: int, file_name='result') -> str:
    oct = ''
    if type == 1:
        oct = '静止'
    if type == 2:
        oct = '行走'
    if type == 3:
        oct = '吃草'
    path = './' + file_name + '-' + oct + '.xlsx'
    ret = rebuild_ret(ret, path)
    ret.to_excel(path, index=False, header=False)
    # print('保存成功: ' + path)
    return path


# 判断是否需要保存文件中现有的数据
def rebuild_ret(ret, path):
    if os.path.exists(path):
        df = pd.read_excel(path, header=None)
        if df.shape[0] == 0:
            return ret
        ret.index = map(lambda x: x, range(df.shape[0], df.shape[0] + ret.shape[0]))
        ret.columns = df.columns
        df.reset_index(drop=True)
        ret.reset_index(drop=True)
        ret = df.append(ret, ignore_index=True)
        return ret
    return ret


# 其他筛选模式数据保存器
def saver(ret, file_name='result'):
    path = './' + file_name + '-' + str(round(tim.time()))[-1] + '.xlsx'
    ret.to_excel(path)
    print('保存成功: ' + path)


# 重建输出表格式
def re_format_table(file_paths: list, old_val='*', new_val=''):
    print('>>>正在重建输出表内容...')
    with tqdm(total=len(file_paths), leave=True) as pbar:
        pbar.set_description("正在处理")
        for _, path in enumerate(file_paths):
            cur_grid = pd.read_excel(path, header=None)
            cur_grid = cur_grid.replace(old_val, new_val)
            cur_grid.to_excel(path, index=False, header=False)
            pbar.update(1)
        print('>>>输出表内容重建完毕, 已保存为以下文件:')
        for _, p in enumerate(file_paths):
            print('* ' + p)


if __name__ == '__main__':
    # 读设置
    print('>>>正在读取设置...')
    settings = json_reader('./settings.json')
    print('>>>设置读取完成')
    base_name = settings["file_name"].split('.')[0]

    oldFiles = [base_name + '-吃草.xlsx',
                base_name + '-行走.xlsx',
                base_name + '-静止.xlsx']
    if check_last_res(oldFiles):
        print('>>>检测到上次生成的结果, 新一轮的筛选操作将删除上一次结果, 请确保已备份相关数据(y/n)', end=' ')
        if input().lower() != 'y':
            print('>>>操作取消')
            sys.exit(0)
        else:
            # 清理上次结果
            clearer(oldFiles)

    print('>>>正在读取数据...')
    # 数据预处理
    datas = pd.read_excel(settings['file_name'], header=None, sheet_name=None)
    # 数据总量
    total = 0
    # 整表
    fillTable = None
    print('>>>检测到该文件中包含' + str(len(datas.items())) + '个sheet')
    for sheet_name, data in datas.items():
        cols = ['-'] * data.shape[1]
        if len(cols) < int(settings['time_column_num']):
            continue
        cols[int(settings['time_column_num']) - 1] = 'time'
        data.columns = cols
        data.index = map(lambda x: x, range(total, total + data.shape[0]))
        fillTable = pd.concat([fillTable, data], axis=0)
        total += len(data)
    print('>>>数据读取完成, 总共 ', total, ' 条记录')

    # test filltable
    # fillTable.to_excel('fillTable.xlsx')

    # multi-range-filter
    if settings["mode"] == 'range':
        print('>>>开始执行range筛选模式...')
        range_data = pd.read_excel(settings['range_file_name'], header=None)
        range_data_len = len(range_data)
        file_paths = []
        with tqdm(total=range_data_len, leave=True) as pbar:
            pbar.set_description("正在处理")
            for index, row in range_data.iterrows():
                ret, remain_data = mode_justifier(fillTable, mode='range',
                                                  value1=time_perser(str(row[0])),
                                                  value2=time_perser(str(row[1])))
                fillTable = remain_data
                file_paths.append(switchSaver(ret, int(row[2]), file_name=base_name))
                pbar.update(1)
            file_paths = list(set(file_paths))
            print('>>>数据筛选完毕')
        # 重建输出表
        re_format_table(file_paths)

    else:
        # other-mode
        ret = mode_justifier(fillTable, mode=settings['mode'], value1=time_perser(settings['value1']),
                             value2=time_perser(settings['value2']))
        saver(ret)
